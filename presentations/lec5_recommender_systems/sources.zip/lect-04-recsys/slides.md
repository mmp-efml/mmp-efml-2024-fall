---
marp: true
math: true
paginate: true
---

<style>
img[alt~="center"] {
  display: block;
  margin: 0 auto;
}
section::after {
  content: attr(data-marpit-pagination) '/' attr(data-marpit-pagination-total);
}
</style>

# DL в рекомендательных системах

Спецкурс *"Введение в эффективные системы ML"*

Алексеев Илья

26 октября 2024

---

## План лекции

- Введение
- Отбор кандидатов
- Ранжирование

---

# Введение

- основные понятия
- постановка задачи
- почему _система_

---

## Понятия

- Два типа объектов: **пользователи** и **предметы**.
- Цель: обеспечить **взаимодействие** пользователя с предметами.

---

## Данные в рекомендательных системах

- о пользователе:
    - пол, возраст, место жительства, история взаимодействий с предметами
- о предмете:
    - размер, дата выхода, вкус, история взаимодействий пользователей
- о взаимодействии:
    - тип, дата, оценка

---

## Постановка задачи

Для пользователя $u$ выдать упорядоченный набор $i_1,\ldots,i_k$, с предметами из которого он точно провзаимодействует.

---

## Рекомендательная _система_

- отбор кандидатов
- ранжирование кандидатов и формирование выдачи

---

# Вопросы??

![bg right width:300](notes.assets/questions-1.png)

---

# Отбор кандидатов

- Поиск по контенту
- Колаборативная фильтрация
- Контрастивное обучение
- Sequential recommenders

---

## Пример: обмен фото

![center width:800](notes.assets/flicker.png)

---

## Поиск по контенту

![center width:450](notes.assets/vector_search.png)

---

## Поиск похожих: плюсы и минусы

Плюсы:

- требует мало данных
- учитываем предпочтения пользователя

Минусы:

- не предлагаем пользователю ничего нового
- не учитываем сторонние признаки о пользователе и взаимодействии

---

# Вопросы??

![bg right width:300](notes.assets/questions-2.png)

---

## Колаборативная фильтрация: KNN

Матрица взаимодействий

$$
R\in\text{Mat}(n_u\times n_i).
$$

Мера близости объекта и пользователя:
$$
\widehat{R}_{ui}={1\over |N(u)|}\sum_{\tilde u\in N(u)} R_{\tilde ui}.
$$

![bg right:41% width:500](notes.assets/interaction_matrix.png)

---

## Колаборативная фильтрация: MF

Обучаем эмбединги $P\in\mathbb{R}^{n_u\times d}$ и $Q\in\mathbb{R}^{n_i\times d}$ на задачу регрессии:

$$
\widehat{R}_{ui}=\langle p_u,q_i\rangle+b_u+b_i+\mu.
$$

Скаляры $b_u,b_i,\mu$ выступают в роли bias'а.

---

## Колаборативная фильтрация: плюсы и минусы

Плюсы:

- рекомендуем новое!
- обучения требуется только матрица взаимодействий
- понятно как деплоить

Минусы:

- проблема холодного старта
- не учитываются сторонние признаки

---

# Вопросы??

![bg right width:300](notes.assets/questions-3.png)

---

## Контрастивное обучение: идея

Что если обучать близости

$$
\boxed{\widehat{R}_{ui}\sim\langle p_u,q_i\rangle}\qquad

\Longrightarrow \qquad

\boxed{\widehat{R}_{ui}\sim\langle p_\phi(u),q_\psi(i)\rangle}
$$


---

## Контрастивное обучение: лосс

In-batch negative sampling

$$
\mathcal{L}_{ui}=-\log{\exp(s(u,i))\over\sum_{z}\exp(s(u,z))},
$$

где $s(u,i)=\langle p_\phi(u),q_\psi(i)\rangle$

![bg right:45% width:350](./notes.assets/project-visualization.drawio.svg)

---

## Контрастивное обучение: плюсы и минусы

Плюсы:
- предсказываем новое
- простота деплоя (опять векторный индекс)
- сторонние признаки
- теплый старт

Минусы:
- сложное обучение
- слабо учитывается контекст и время

---

## Sequential Recommenders

![](notes.assets/toys.png)

---

## Sequential Recommenders

![](notes.assets/cloth.png)

---

## SASRec: идея

![center width:550](./notes.assets/image-20241025232311235.png)

---

## SASRec: связь с колаборативной фильтрацией

Финальная классификация на число всех предметов:

$$
\text{Softmax}(Wh_t)\in\mathbb{R}^{n_i},
$$

где $W\in\mathbb{R}^{n_i\times d}$.

---

# Вопросы??

![bg right width:300](notes.assets/questions-4.png)

---

# Ранжирование

- Методы: pointwise, pairwise, listwise
- LambdaRank

---

## Ранжирование: постановка задачи

Имеется пользователь $u$ и набор кандидатов $\{i_1,\ldots,i_k\}$. Задача: отсортировать (=отранжировать) кандидатов по релевантности.

![bg right:40%](notes.assets/feed.png)

---

## Pointwise ранжирование

![center width:600](notes.assets/pointwise.drawio.svg)

---

## Pairwise ранжирование

![center width:600](notes.assets/pairwise.drawio.svg)

---

## Listwise ранжирование

![center width:600](notes.assets/listwise.drawio.svg)

---

# Важнее сеть, а не лосс

![center width:600](notes.assets/dcn.png)

---

## Вывод LambdaRank

обратимся к доске! если вы еще живы... 💀

![bg right width:300](notes.assets/head.png)
